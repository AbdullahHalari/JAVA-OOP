package bankaccount;

import java.util.Scanner;


public class CurrentAcc extends BankAccount{    //inheritance
    
    private float balance;  // using Access
    float amount;
    Scanner sc = new Scanner(System.in);
    
    CurrentAcc(float balance, String Name, int pin){ //constructor
        super(Name, pin);                         
        this.balance = balance;
    }
    
    float getbalance(){     //Access modifier
        return balance;
    }
    
    void depositAmt(){
        float amount;
        System.out.println("Enter deposit amount: ");
        amount = Integer.parseInt(sc.nextLine());
        if(0 > amount){
            System.out.println("Invalid amount!");
            depositAmt();
        }
        else{
            balance = balance + amount;
            System.out.println("Your cash has been deposited successfully!");
        }
        

    }
    
    void withdrawAmt(float amount){ //
        this.amount = amount;
        
        System.out.println("Enter withdrawal amount: ");
        amount = Integer.parseInt(sc.nextLine());
        if(0 > amount){
            System.out.println("Invalid amount!");
            withdrawAmt(amount);
        }
        else if(amount > balance){
            System.out.println("You have insufficient Balance!");
        }
        else{
            balance = balance - amount;
            System.out.println("Your cash has been withdrawn successfully!");
        }
        
    } 


    void viewAmt(){
        System.out.println("Account Balance: " + balance);
    }
    
    public void home(){
        System.out.println("LOAN CONDITIONS: \nInterest Rate is 4% after 12 months \nMinimum Amount 2,00,000  \nMaximum 20,00,000 \nTime Period 2 to 5 years");
        
        System.out.println("How much loan you want:");
        int loan = sc.nextInt();

        System.out.println("How many years would you like to repay?");
        int time = sc.nextInt();

    
        if(loan >= 200000){
            if(time==1){
                System.out.println("SUCCESSFULLY your loan application accepted ");
                System.out.println("you repay" + loan + "with 12months");
            }
            else{
                System.out.println("SUCCESSFULLY your loan application accepted ");
                int interest = loan*4/100;
                int year = (time-1)*interest;
                System.out.println("you repay " + (loan+year) + " with in " + time + " years" );
            }
        }
        else{
            
            System.out.println("you must apply for loan upto 2,00,000");
        }
    
    
    
    }

    public void bussiness(){
        System.out.println("LOAN CONDITIONS: \nInterest Rate is 2%  \nMinimum Amount 1,00,000  \nMaximum 10,00,000 \nTime Period 1 to 3 years");
        
        System.out.println("How much loan you want:");
        int loan = sc.nextInt();

        System.out.println("How long would you like to repay?");
        int time = sc.nextInt();

    
        if(loan >= 100000){
           
                System.out.println("SUCCESSFULLY your loan application accepted ");
                int interest = loan*2/100;
                int year = (time)*interest;
                System.out.println("you repay " + (loan+year) + " with in " + time + " years" );
            
        }
        else{
            
            System.out.println("you must apply for loan upto 1,00,000");
        }
    
    
    
    }
    public void other(){
        System.out.println("LOAN CONDITIONS: \nInterest Rate is 3%  \nMinimum Amount 50,000  \nMaximum 5,00,000 \nTime Period 1 to 4 years");
    
        System.out.println("How much loan you want:");
        int loan = sc.nextInt();

        System.out.println("How many years would you like to repay ?");
        int time = sc.nextInt();

        System.out.println("What are you borrowing for ?");
        String others = sc.next();

        if(loan >= 50000){
           
                System.out.println("SUCCESSFULLY your loan application for " + others + " accepted.");
                int interest = loan*3/100;
                int year = (time)*interest;
                System.out.println("you repay " + (loan+year) + " with in " + time + " years" );
            
        }
        else{
            
            System.out.println("you must apply for loan upto 50,000");
        }
    
    
    
    }
void loan_types(){
     System.out.println("do you want loan:"); 
               String ask_loan = sc.nextLine();
                if(ask_loan.equals("yes")){

                    boolean quit = false;
                    int a;
                    
                    
                    do{ 
                    
                        System.out.println("Do You want to: \n1]LOAN FOR HOME\n2]LOAN FOR BUSSINESS\n3]LOAN FOR OTHERS \n4] Quit\nEnter your choice:");
                        // a = Integer.parseInt(sc.nextLine());
                        a = sc.nextInt();
                        switch(a){
                        
                            case 1:
                                home();
                                break;
                            case 2:
                                bussiness();
                                break;
                            case 3:
                                other();
                                break;
                            case 4:
                                // quit = true;
                                // break;
                                cas
                            default:
                                System.out.println("Invalid option!");
                                break;
                            }
                    }while(quit!=true);
                }  
                else {
                    
                    System.out.println("Thank you for your response");
                }    

  
}








    void cashopt(){
        boolean quit = false;
        int a;
        
        
        do{ 
        
            System.out.println("Do You want to: \n1] Deposit Amount\n2] Withdraw Amount\n3] View Account\n4] Quit\nEnter your choice:");
            a = Integer.parseInt(sc.nextLine());
            
            switch(a){
            
                case 1:
                    depositAmt();
                    break;
                case 2:
                    withdrawAmt(amount);
                    break;
                case 3:
                    viewAmt();
                    break;
                case 4:
                    // Loan l = new Loan(name,pin);
                    // l.loan_types();
                    loan_types();
                    
                    break;
                case 5:
                    quit = true;
                    break;
                default:
                    System.out.println("Invalid option!");
                    break;
                }
        }while(quit!=true);
}
}
    
